package animals;

public interface ITerrestrialAnimal {
    int getNoLegs();
}
