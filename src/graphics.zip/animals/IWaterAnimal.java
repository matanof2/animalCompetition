package animals;

public interface IWaterAnimal {
    boolean dive(double depth);
    double getDiveDept();
}
